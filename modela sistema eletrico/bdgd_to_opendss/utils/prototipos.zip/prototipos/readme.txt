Scripts sem compromisso, tentando modelar a rede de um CTMT como um grafo

Na duvida se modelo cada CTMT ou o circuito da subestação inteira de uma vez

Se modelar cada CTMT, eu perco alguma informação de chaves?