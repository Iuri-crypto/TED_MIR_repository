from collections import defaultdict
import pandas as pd
import networkx as nx


path = r"C:\Users\Lucas Maximus\Desktop\BDGD\csv"

df_1 = pd.read_csv(path + r"\SSDMT.csv",dtype=str) #segmentos
df_2 = pd.read_csv(path + r"\UNTRMT.csv",dtype=str) #trafos
df_3 = pd.read_csv(path + r"\UNSEMT.csv",dtype=str) #chaves
df_4 = pd.read_csv(path + r"\UNTRAT.csv",dtype=str) #trafos alta tensao
df_5 = pd.read_csv(path + r"\CTMT.csv",dtype=str) #ctmt

CODIGO_SUB = '476637'



#pegue os trafos dessa subestacao
dict_untrat = (df_4[df_4["SUB"] == CODIGO_SUB]).to_dict(orient='records')


dicionarioCTMT = df_5.to_dict(orient='records')


#dicionarios
dict_trafo_at_ctmt_cod_id = defaultdict(list)
dict_trafo_at_ctmt_pac_ini = defaultdict(list)
dicionarioPacIniIdentificador = dict()
dicionario_pac_cod_id = defaultdict(list)
cod_id_pac_1_pac_2 = defaultdict(set)
objeto_vizinhos = defaultdict(set)
dicionarioBarraId = dict()


#conjuntos
conjuntoTodosPacIniSistema = set()
conjuntoChaves = set()
conjuntoTrafos = set()
conjuntoTrafosAT = set()
conjuntoSegmentos = set()
conjuntoTodosPAC = set()
conjuntoTodasBarrasIni = set() 


#listas
listaTodosCTMTSistema = list()



for ctmt in dicionarioCTMT:
    dict_trafo_at_ctmt_cod_id[ctmt['UNI_TR_AT']].append(ctmt['COD_ID'])
    dict_trafo_at_ctmt_pac_ini[ctmt['UNI_TR_AT']].append(ctmt['PAC_INI'])
    
for trafo in dict_untrat:
    listaTodosCTMTSistema.extend(dict_trafo_at_ctmt_cod_id[trafo['COD_ID']])
    conjuntoTodosPacIniSistema.update(dict_trafo_at_ctmt_pac_ini[trafo['COD_ID']])
    conjuntoTodasBarrasIni.add(trafo['BARR_1'])

for i, j in enumerate(conjuntoTodosPacIniSistema, start=1):
    dicionarioPacIniIdentificador[j] = i
   

if len(conjuntoTodasBarrasIni) == 1:
    barra_1 = list(conjuntoTodasBarrasIni)[0]
else:
    print(conjuntoTodasBarrasIni)
    exit()


dict_ssdmt = (df_1[df_1['CTMT'].isin(listaTodosCTMTSistema)]).to_dict(orient='records')
dict_untrmt = (df_2[df_2['CTMT'].isin(listaTodosCTMTSistema)]).to_dict(orient='records')
dict_unsemt = (df_3[df_3['CTMT'].isin(listaTodosCTMTSistema)]).to_dict(orient='records')

df_1 = df_2 = df_3 = None


for ssdmt in dict_ssdmt:
    dicionario_pac_cod_id[ssdmt['PAC_1']].append(ssdmt['COD_ID'])
    dicionario_pac_cod_id[ssdmt['PAC_2']].append(ssdmt['COD_ID'])
    conjuntoSegmentos.add(ssdmt['COD_ID'])


for untrmt in dict_untrmt:
    dicionario_pac_cod_id[untrmt['PAC_1']].append(untrmt['COD_ID'])
    dicionario_pac_cod_id[untrmt['PAC_2']].append(untrmt['COD_ID'])
    conjuntoTrafos.add(untrmt['COD_ID'])

for unsemt in dict_unsemt:
    dicionario_pac_cod_id[unsemt['PAC_1']].append(unsemt['COD_ID'])
    dicionario_pac_cod_id[unsemt['PAC_2']].append(unsemt['COD_ID'])
    conjuntoChaves.add(unsemt['COD_ID'])


for trafo in dict_untrat:
    pac_ini_trafo = dict_trafo_at_ctmt_pac_ini[trafo['COD_ID']]

    pac_1 = trafo['PAC_2']

    for i in pac_ini_trafo:
        pac_2 = i

        cod_id =f"PAC_INI_{dicionarioPacIniIdentificador[i]}"

        dicionario_pac_cod_id[pac_1].append(cod_id)
        dicionario_pac_cod_id[pac_2].append(cod_id)

for trafo in dict_untrat:
    dicionario_pac_cod_id[trafo['PAC_1']].append(barra_1)
    dicionario_pac_cod_id[trafo['PAC_1']].append(trafo['COD_ID'])
    dicionario_pac_cod_id[trafo['PAC_2']].append(trafo['COD_ID'])
    conjuntoTrafosAT.add(trafo['COD_ID'])





lista_arestas = list()

'''

for trafo in dict_untrat:
    chave = trafo['COD_ID']
    print(chave)

    lista_pac_ini_trafo = DICT_TRAFO_AT_CTMT_PAC_INI[chave]

    for pac in lista_pac_ini_trafo:
        dicionario_pac_cod_id[pac].append(chave)

'''

for x,y in dicionario_pac_cod_id.items():

    for i in y:
        for j in y:
            if i == j:
                continue
            else:
                lista_arestas.append((i,j))            


print("terminei")






G = nx.Graph()
G.add_edges_from(lista_arestas)


B = nx.bfs_tree(G,barra_1)


A = nx.nx_agraph.to_agraph(B)

A.graph_attr["nodesep"] = "3" #separacao horizontal dos nos no grafo
A.graph_attr["ranksep"] = "3" #separacao vertical dos nos no grafo

A.node_attr["shape"] = "circle"


A.edge_attr["arrowsize"] = "1"
A.edge_attr["weight"] = "2"



for node in A.nodes():

    if node in conjuntoChaves:


        no = A.get_node(node)

        no.attr["color"] = "yellow"
        no.attr["shape"] = "box"
        no.attr['style'] = "filled"
        no.attr['fontcolor'] = 'black'
        no.attr["fixedsize"] = 'false'

    
    if node in conjuntoTrafos:
 
        
        no = A.get_node(node)

        no.attr["color"] = "red"
        no.attr['style'] = "filled"
        no.attr['fontcolor'] = 'green'
        no.attr["fixedsize"] = 'false'
            

    if node in conjuntoSegmentos:


        no = A.get_node(node)


        no.attr["color"] = "green"
        no.attr["shape"] = "square"
        no.attr['style'] = "filled"
        no.attr['fontcolor'] = 'red'
        no.attr["fixedsize"] = 'false'
    
    
    if node in conjuntoTrafosAT:

        no = A.get_node(node)

        no.attr["color"] = "blue"
        no.attr["shape"] = "circle"
        no.attr['style'] = "filled"
        no.attr['fontcolor'] = 'white'
        no.attr["fixedsize"] = 'false'

    if node == barra_1:
        no = A.get_node(node)

        no.attr["color"] = "black"
        no.attr["shape"] = "rect"
        no.attr['style'] = "filled"
        no.attr['fontcolor'] = 'white'
        no.attr["fixedsize"] = 'false'


    



A.layout(prog="dot")
A.draw('grafo.svg')


