from collections import defaultdict
import pandas as pd
import networkx as nx

path = r"C:\Users\Lucas Maximus\Desktop\BDGD\csv"

df_1 = pd.read_csv(path + r"\SSDMT.csv",dtype=str) #segmentos
df_2 = pd.read_csv(path + r"\UNTRMT.csv",dtype=str) #trafos
df_3 = pd.read_csv(path + r"\UNSEMT.csv",dtype=str) #chaves

dict_ssdmt = df_1.to_dict(orient='records') #lista de dicionarios
dict_untrmt = df_2.to_dict(orient='records') #lista de dicionarios
dict_unsemt = df_3.to_dict(orient='records') #lista de dicionarios

df_1 = df_2 = df_3 = None

conjunto_todos_pac = set()
conjunto_trafos_cod_id = set()
conjunto_ssdmt_cod_id = set()

dicionario_pac_vizinhos = dict()
ssdmt_cod_id_ct_cod_op = dict()

dicionario_pac_cod_id = defaultdict(set)
cod_id_pac_1_pac_2 = defaultdict(set)
pac_ct_cod_op = defaultdict(set)



for ssdmt in dict_ssdmt:
    conjunto_todos_pac.add(ssdmt['PAC_1'])
    conjunto_todos_pac.add(ssdmt['PAC_2'])

    dicionario_pac_cod_id[ssdmt['PAC_1']].add(ssdmt['COD_ID'])
    dicionario_pac_cod_id[ssdmt['PAC_2']].add(ssdmt['COD_ID'])

    cod_id_pac_1_pac_2[ssdmt['COD_ID']].update([ssdmt['PAC_1'],ssdmt['PAC_2']])

    conjunto_ssdmt_cod_id.add(ssdmt['COD_ID'])

    ssdmt_cod_id_ct_cod_op[ssdmt['COD_ID']] = ssdmt['CT_COD_OP']




for untrmt in dict_untrmt:
    conjunto_todos_pac.add(untrmt['PAC_1'])
    conjunto_todos_pac.add(untrmt['PAC_2'])

    dicionario_pac_cod_id[untrmt['PAC_1']].add(untrmt['COD_ID'])
    dicionario_pac_cod_id[untrmt['PAC_2']].add(untrmt['COD_ID'])

    cod_id_pac_1_pac_2[untrmt['COD_ID']].update([untrmt['PAC_1'],untrmt['PAC_2']])

    conjunto_trafos_cod_id.add(untrmt['COD_ID'])


for unsemt in dict_unsemt:
    conjunto_todos_pac.add(unsemt['PAC_1'])
    conjunto_todos_pac.add(unsemt['PAC_2'])

    dicionario_pac_cod_id[unsemt['PAC_1']].add(unsemt['COD_ID'])
    dicionario_pac_cod_id[unsemt['PAC_2']].add(unsemt['COD_ID'])

    cod_id_pac_1_pac_2[unsemt['COD_ID']].update([unsemt['PAC_1'],unsemt['PAC_2']])


for x,y in dicionario_pac_cod_id.items():
    
    tmp_set = set()

    for id in y:
        tmp_set.update(cod_id_pac_1_pac_2[id])

    resultado = tmp_set ^ {x}

    dicionario_pac_vizinhos[x] = resultado

    #print(x,y,tmp_set,resultado)


for id in conjunto_todos_pac:

    tmp_set = set()

    objetos_conectados = dicionario_pac_cod_id[id]

    segmentos_conectados = objetos_conectados & conjunto_ssdmt_cod_id

    for i in segmentos_conectados:
        tmp_set.add(ssdmt_cod_id_ct_cod_op[i])

    pac_ct_cod_op[id].update(tmp_set)




for untrmt in dict_untrmt:
    
    if len(pac_ct_cod_op[untrmt['PAC_1']]) == 1:
        #PAC 1 DO TRAFO TEM CT_COD_OP
        pass
    elif len(pac_ct_cod_op[untrmt['PAC_1']]) == 0:
        #PAC 1 DO TRAFO NAO TEM CT_COD_OP
        fila = [untrmt['PAC_1']]
        
        visitados = set()
        tmp_set = set()
        
        while fila:
            escolhido = fila.pop(0)

            if escolhido not in visitados:
                for ct_op in pac_ct_cod_op[escolhido]:
                    tmp_set.add(ct_op)

                visitados.add(escolhido)  

                      
                for vizinho in dicionario_pac_vizinhos[escolhido]:
                    if (vizinho not in visitados) and (len(tmp_set) == 0):
                        fila.append(vizinho)

       
        if len(tmp_set) >=2:
            print(untrmt['COD_ID'],untrmt['PAC_1'],visitados,tmp_set)
     




'''
for untrmt in dict_untrmt:
    
    if len(pac_ct_cod_op[untrmt['PAC_1']]) == 1:
        #PAC 1 DO TRAFO TEM CT_COD_OP
        pass
    elif len(pac_ct_cod_op[untrmt['PAC_1']]) == 0:
        #PAC 1 DO TRAFO NAO TEM CT_COD_OP

        tmp_set = set()
        #pegue os vizinhos desse PAC
        vizinhos = dicionario_pac_vizinhos[untrmt['PAC_1']]

        for id in vizinhos:

            for ct_op in pac_ct_cod_op[id]:

                tmp_set.add(ct_op)

        print(untrmt['PAC_1'], tmp_set)

'''
