from collections import defaultdict
import pandas as pd
import networkx as nx


path = r"C:\Users\Lucas Maximus\Desktop\BDGD\csv"

#GERA O GRAFO ONDE OS NOS SAO COD_ID



CTMT = '2014294'

df_1 = pd.read_csv(path + r"\SSDMT.csv",dtype=str) #segmentos
df_2 = pd.read_csv(path + r"\UNTRMT.csv",dtype=str) #trafos
df_3 = pd.read_csv(path + r"\UNSEMT.csv",dtype=str) #chaves

df_filtrado_1 = df_1[df_1['CTMT'] == CTMT]
df_filtrado_2 = df_2[df_2['CTMT'] == CTMT]
df_filtrado_3 = df_3[df_3['CTMT'] == CTMT]

dict_ssdmt = df_filtrado_1.to_dict(orient='records') #lista de dicionarios
dict_untrmt = df_filtrado_2.to_dict(orient='records') #lista de dicionarios
dict_unsemt = df_filtrado_3.to_dict(orient='records') #lista de dicionarios

df_filtrado_1 = df_filtrado_2 = df_filtrado_3 = None
df_1 = df_2 = df_3 = None







qntdChaves = len(dict_unsemt)
qntdTrafos = len(dict_untrmt)
qntdSegmentos = len(dict_ssdmt)

print(f"QNTD CHAVES: {qntdChaves}")
print(f"QNTD TRAFOS: {qntdTrafos}")
print(f"QNTD SEGMENTOS: {qntdSegmentos}")





conjuntoChaves = set()
conjuntoTrafos = set()
conjuntoSegmentos = set()




conjuntoTodosPAC = set() #Todos os PACs dos elementos que compoem o sistema. Cada PAC é uma barra.

# Associa um PAC com os COD_ID dos objetos conectados a ele
dicionario_pac_cod_id = defaultdict(list)

# Associa o cod_id do objeto com o pac_1 e pac_2
cod_id_pac_1_pac_2 = defaultdict(set)

objeto_vizinhos = defaultdict(set)

for ssdmt in dict_ssdmt:
    conjuntoTodosPAC.add(ssdmt['PAC_1'])
    conjuntoTodosPAC.add(ssdmt['PAC_2'])

    dicionario_pac_cod_id[ssdmt['PAC_1']].append(ssdmt['COD_ID'])
    dicionario_pac_cod_id[ssdmt['PAC_2']].append(ssdmt['COD_ID'])

    cod_id_pac_1_pac_2[ssdmt['COD_ID']].update([ssdmt['PAC_1'],ssdmt['PAC_2']])

    conjuntoSegmentos.add(ssdmt['COD_ID'])



for untrmt in dict_untrmt:
    conjuntoTodosPAC.add(untrmt['PAC_1'])
    conjuntoTodosPAC.add(untrmt['PAC_2'])

    dicionario_pac_cod_id[untrmt['PAC_1']].append(untrmt['COD_ID'])
    dicionario_pac_cod_id[untrmt['PAC_2']].append(untrmt['COD_ID'])

    cod_id_pac_1_pac_2[untrmt['COD_ID']].update([untrmt['PAC_1'],untrmt['PAC_2']])

    conjuntoTrafos.add(untrmt['COD_ID'])


for unsemt in dict_unsemt:
    conjuntoTodosPAC.add(unsemt['PAC_1'])
    conjuntoTodosPAC.add(unsemt['PAC_2'])

    dicionario_pac_cod_id[unsemt['PAC_1']].append(unsemt['COD_ID'])
    dicionario_pac_cod_id[unsemt['PAC_2']].append(unsemt['COD_ID'])

    cod_id_pac_1_pac_2[unsemt['COD_ID']].update([unsemt['PAC_1'],unsemt['PAC_2']])

    conjuntoChaves.add(unsemt['COD_ID'])




lista_arestas = list()


for x,y in dicionario_pac_cod_id.items():

    for i in y:
        for j in y:
            if i == j:
                continue
            else:
                lista_arestas.append((i,j))            




G = nx.Graph()
G.add_edges_from(lista_arestas)


B = nx.bfs_tree(G,"584202")


A = nx.nx_agraph.to_agraph(B)

A.graph_attr["nodesep"] = "3" #separacao horizontal dos nos no grafo
A.graph_attr["ranksep"] = "3" #separacao vertical dos nos no grafo

A.node_attr["shape"] = "circle"


A.edge_attr["arrowsize"] = "1"
A.edge_attr["weight"] = "2"

contadorChaves = contadorTrafos = contadorSegmentos = 0

for node in A.nodes():

    if node in conjuntoChaves:
        contadorChaves+=1

        no = A.get_node(node)

        no.attr["color"] = "yellow"
        no.attr["shape"] = "box"
        no.attr['style'] = "filled"
        no.attr['fontcolor'] = 'black'
        no.attr["fixedsize"] = 'false'

    
    if node in conjuntoTrafos:
        contadorTrafos+=1
        
        no = A.get_node(node)

        no.attr["color"] = "red"
        no.attr['style'] = "filled"
        no.attr['fontcolor'] = 'green'
        no.attr["fixedsize"] = 'false'
            

    if node in conjuntoSegmentos:
        contadorSegmentos+=1

        no = A.get_node(node)


        no.attr["color"] = "green"
        no.attr["shape"] = "square"
        no.attr['style'] = "filled"
        no.attr['fontcolor'] = 'red'
        no.attr["fixedsize"] = 'false'
    
    

    

print()
print(f"QNTD CHAVES: {contadorChaves}")
print(f"QNTD TRAFOS: {contadorTrafos}")
print(f"QNTD SEGMENTOS: {contadorSegmentos}")


A.layout(prog="dot")
A.draw('grafo.svg')









